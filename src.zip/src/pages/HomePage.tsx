import ClientList from "../components/ClientList";

export default function HomePage() {
  return (
    <main className="bg-light min-vh-100">
      <ClientList />
    </main>
  );
}
