import ClienteDetails from "../components/ClienteDetails";

export default function Cliente() {
  return (
    <main className="bg-light min-vh-100">
      <ClienteDetails />
    </main>
  );
}
