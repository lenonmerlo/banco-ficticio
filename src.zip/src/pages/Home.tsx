import ClienteList from "../components/ClienteList";

export default function Home() {
  return (
    <main className="bg-light min-vh-100">
      <ClienteList />
    </main>
  );
}
