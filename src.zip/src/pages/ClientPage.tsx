import ClientDetails from "../components/ClientDetails";

export default function ClientPage() {
  return (
    <main className="bg-light min-vh-100">
      <ClientDetails />
    </main>
  );
}
