import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { Client, Account, Agency } from "../types";
import { fetchCSV } from "../services/fetchCSV";

const URL_CLIENTS =
  "https://docs.google.com/spreadsheets/d/1PBN_HQOi5ZpKDd63mouxttFvvCwtmY97Tb5if5_cdBA/gviz/tq?tqx=out:csv&sheet=clientes";
const URL_ACCOUNTS =
  "https://docs.google.com/spreadsheets/d/1PBN_HQOi5ZpKDd63mouxttFvvCwtmY97Tb5if5_cdBA/gviz/tq?tqx=out:csv&sheet=contas";
const URL_AGENCIES =
  "https://docs.google.com/spreadsheets/d/1PBN_HQOi5ZpKDd63mouxttFvvCwtmY97Tb5if5_cdBA/gviz/tq?tqx=out:csv&sheet=agencias";

interface BankContextType {
  clients: Client[];
  accounts: Account[];
  agencies: Agency[];
  loading: boolean;
}

const BankContext = createContext<BankContextType>({
  clients: [],
  accounts: [],
  agencies: [],
  loading: true,
});

export const useBank = () => useContext(BankContext);

export function BankProvider({ children }: { children: ReactNode }) {
  const [clients, setClients] = useState<Client[]>([]);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [agencies, setAgencies] = useState<Agency[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadAll = async () => {
      const [clientsCSV, accountsCSV, agenciesCSV] = await Promise.all([
        fetchCSV<Client>(URL_CLIENTS),
        fetchCSV<Account>(URL_ACCOUNTS),
        fetchCSV<Agency>(URL_AGENCIES),
      ]);

      const normalizedClients = clientsCSV.map((c) => ({
        ...c,
        birthDate: new Date(c.birthDate),
        annualIncome: Number(c.annualIncome),
        assets: Number(c.assets),
        agencyCode: Number(c.agencyCode),
        name: c.name,
        socialName: c.socialName,
        address: c.address,
        maritalStatus: c.maritalStatus,
      }));

      const normalizedAccounts = accountsCSV.map((c) => ({
        ...c,
        balance: Number(c.balance),
        creditLimit: Number(c.creditLimit),
        availableCredit: Number(c.availableCredit),
        clientCpfCnpj: c.clientCpfCnpj,
        type: c.type,
      }));

      const normalizedAgencies = agenciesCSV.map((a) => ({
        ...a,
        code: Number(a.code),
        name: a.name,
        address: a.address,
      }));

      setClients(normalizedClients);
      setAccounts(normalizedAccounts);
      setAgencies(normalizedAgencies);
      setLoading(false);
    };

    loadAll();
  }, []);

  return (
    <BankContext.Provider value={{ clients, accounts, agencies, loading }}>
      {children}
    </BankContext.Provider>
  );
}
